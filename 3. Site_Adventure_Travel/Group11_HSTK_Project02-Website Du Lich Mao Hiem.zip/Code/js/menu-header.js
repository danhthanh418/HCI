$(function(){
	$(".menu-tour").click(function(){
		$(".navbar-collapse-menu-child").css("display","block");
	});
});