Bài của nhóm đã upload lên server Azure. Thầy có thể xem trực tuyến tại địa chỉ:
http://hci-travel.azurewebsites.net/